# Project Details

# Compatibility Note
- Python: >=3.9
- Flask: >=2.x
- MySQL: >=8.x

---

# Installation Guide

### 1. Install Python & MySQL
Make sure you have Python and MySQL installed on your machine by following the appropriate installation guides:
- [Python installation guide](https://www.python.org/downloads/)
- [MySQL installation guide](https://dev.mysql.com/downloads/installer/)

### 2. How to run this project

1. Check the Python version to ensure it's installed correctly:
   ```bash
   python --version
   ```

2. Clone the repository or download the zip file:
   ```bash
   git clone https://github.com/JokiProyek/suhu-kelembaban-web.git
   ```

3. Navigate to the project directory:
   ```bash
   cd <project-folder>
   ```

4. Set up a virtual environment (recommended):
   ```bash
   python -m venv .venv
   ```

5. Activate the virtual environment:
   - On macOS/Linux:
     ```bash
     source .venv/bin/activate
     ```
   - On Windows:
     ```bash
     .venv\Scripts\activate
     ```

6. Install the project dependencies:
   ```bash
   pip install -r requirements.txt
   ```

7. Prepare the `.env` file:
   - In the root directory, create a `.env` file.
   - Add the following environment variables:

   ```env
   MYSQL_HOST=localhost
   MYSQL_USER=<your_mysql_username>
   MYSQL_PASSWORD=<your_mysql_password>
   MYSQL_DB=<your_database_name>
   SECRET_KEY=<your_flask_secret_key>
   ```

8. Set up the MySQL database:
   - Log into your MySQL database and create the necessary database and table:
   ```sql
   CREATE DATABASE your_database_name;
   USE your_database_name;
   CREATE TABLE tb_sensor (
       id INT AUTO_INCREMENT PRIMARY KEY,
       suhu FLOAT,
       kelembaban FLOAT,
       timestamp DATETIME
   );
   ```

9. Run the Flask development server:
   ```bash
   flask run
   ```

   or if using `app.py` as the main file:

   ```bash
   python app.py
   ```

10. Open the project in your browser:
   ```
   http://localhost:5000
   ```

### 3. Running the Application

- After running the development server, visit `http://localhost:5000` to view the home page.

# Local Testing
* Main Page: ![Login Page](/public/screenshots/app.png)