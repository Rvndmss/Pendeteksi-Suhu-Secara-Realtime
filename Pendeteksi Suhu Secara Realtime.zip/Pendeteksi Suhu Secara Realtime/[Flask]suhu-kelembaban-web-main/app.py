import os
from flask import Flask, render_template, request, jsonify
from flask_mysqldb import MySQL
from dotenv import load_dotenv

# Load environment variables from the .env file
load_dotenv()

app = Flask(__name__)

# MySQL configuration using environment variables
app.config['MYSQL_HOST'] = os.getenv('MYSQL_HOST')
app.config['MYSQL_USER'] = os.getenv('MYSQL_USER')
app.config['MYSQL_PASSWORD'] = os.getenv('MYSQL_PASSWORD')
app.config['MYSQL_DB'] = os.getenv('MYSQL_DB')
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY')

# Initialize MySQL
mysql = MySQL(app)

@app.route("/")
@app.route("/index")
def index():
    return render_template("index.html")

@app.route("/add", methods=["POST"])
def add():
    if request.method == "POST":
        name = request.form['name']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO your_table_name (name) VALUES (%s)", [name])
        mysql.connection.commit()
        cur.close()
        return jsonify(message="Data added successfully")

@app.route("/get_sensor_data", methods=["GET"])
def get_sensor_data():    
    cur = mysql.connection.cursor()

    cur.execute("SELECT suhu, kelembaban FROM tb_sensor")
    
    data = cur.fetchall()
    
    cur.close()
    
    result = [{"suhu": row[0], "kelembaban": row[1]} for row in data]
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)
