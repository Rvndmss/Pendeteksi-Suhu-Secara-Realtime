<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Suhu extends CI_Controller {

    public function __construct() {
        parent::__construct();
        // Load model atau library yang diperlukan
    }

    public function index() {
        $data = array(
            'suhu' => $this->get_suhu() // Fungsi untuk mendapatkan suhu dari NodeMCU
        );
        header('Content-Type: application/json');
        echo json_encode($data);
    }

    private function get_suhu() {
        // Logika untuk mendapatkan data suhu dari NodeMCU
        // Misalnya, ambil dari database atau API
        return 25; // Contoh suhu statis
    }
}