<?php
	echo $data_sensor->suhu;
?>