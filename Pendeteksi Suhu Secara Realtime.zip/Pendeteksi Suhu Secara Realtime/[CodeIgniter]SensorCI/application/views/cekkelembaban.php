<?php
	echo $data_sensor->kelembaban;
?>